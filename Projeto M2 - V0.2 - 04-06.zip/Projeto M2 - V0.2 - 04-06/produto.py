class Produto:
    def __init__(self, codigo_barras, nome, valor_unitario, quantidade):
        self.codigo_barras = codigo_barras
        self.nome = nome
        self.valor_unitario = valor_unitario
        self.quantidade = quantidade
