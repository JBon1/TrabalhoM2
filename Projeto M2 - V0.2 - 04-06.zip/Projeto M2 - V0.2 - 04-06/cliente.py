class Cliente:
    def __init__(self, cpf, nome, email, telefone, cidade):
        self.cpf = cpf
        self.nome = nome
        self.email = email
        self.telefone = telefone
        self.cidade = cidade
