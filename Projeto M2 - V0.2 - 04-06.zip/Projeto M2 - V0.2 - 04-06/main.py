# main.py
from cliente import Cliente
from db import inserir_cliente, consultar_clientes, inserir_produto, consultar_produtos
import gui

# Iniciar a GUI
import gui